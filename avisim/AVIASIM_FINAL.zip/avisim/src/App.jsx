import { useState } from 'react'
import './index.css'
function App() {
  const [screen, setScreen] = useState('home')
const [engineRPM, setEngineRPM] = useState(8500)
  const [engineSection, setEngineSection] = useState('full')

  return (
    <div className="app">
      <nav>
        <div className="logo">AVIAS<span>IM</span></div>
        <ul className="nav-links">
          <li><a href="#" onClick={() => setScreen("home")}>Home</a></li>
          <li><a href="#" onClick={() => setScreen("admin")}>Admin</a></li>
          <li><a href="#" onClick={() => setScreen("engine")}>Engine</a></li>
          <li><a href="#" onClick={() => setScreen("aircraft")}>Aircraft</a></li>
          <li><a href="#" onClick={() => setScreen("analysis")}>Analysis</a></li>
          <li><a href="#" onClick={() => setScreen("drawings")}>Drawings</a></li>
        </ul>
      </nav>

      <main className="content">
        {screen === "home" && <HomeScreen setScreen={setScreen} />}
        {screen === "admin" && <AdminScreen setScreen={setScreen} />}
        {screen === "engine" && <EngineScreen setScreen={setScreen} engineRPM={engineRPM} setEngineRPM={setEngineRPM} engineSection={engineSection} setEngineSection={setEngineSection} />}
        {screen === "aircraft" && <AircraftScreen setScreen={setScreen} />}
        {screen === "analysis" && <AnalysisScreen />}
        {screen === "drawings" && <DrawingsScreen />}
      </main>
    </div>
  )
function HomeScreen({ setScreen }) {
  return (
    <section className="screen home">
      <div className="hero">
        <div className="hero-grid">
          <div className="hero-content">
            <h1>Aviation <span>Simulation</span></h1>
            <p>Advanced aircraft engine monitoring and analysis platform</p>
            <div className="hero-badge">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <circle cx="12" cy="12" r="10"></circle>
                <path d="M8 14s1.5 2 4 2 4-2 4-2"></path>
                <line x1="9" y1="9" x2="9.01" y2="9"></line>
                <line x1="15" y1="9" x2="15.01" y2="9"></line>
              </svg>
              WebGL Rendered
            </div>
          </div>
          <div>
            <canvas id="engine-canvas" className="canvas-gl" />
          </div>
        </div>
      </section>
    </section>
  )
}
function AdminScreen({ setScreen }) {
  return (
    <section className="screen admin">
      <h2>Administration Panel</h2>
      <div className="card">
        <h3>System Status</h3>
        <div className="status-dot"></div>
        <p>System online</p>
      </div>
      <div className="card">
        <h3>Configuration</h3>
        <button className="btn btn-primary">View Settings</button>
        <button className="btn btn-secondary">Export Data</button>
      </div>
    </section>
  )
}
}
function EngineScreen({ setScreen, engineRPM, setEngineRPM, engineSection, setEngineSection }) {
  return (
    <section className="screen engine">
      <h2>Turbofan Engine Model</h2>
      <div className="card">
        <h3>Engine Parameters</h3>
        <table className="table">
          <thead>
            <tr>
              <th>Parameter</th>
              <th>Value</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>RPM</td>
              <td>{engineRPM}</td>
              <td><span className="status-dot"></span> Normal</td>
            </tr>
            <tr>
              <td>Temperature</td>
              <td>720&deg;C</td>
              <td><span className="status-dot"></span> Normal</td>
            </tr>
            <tr>
              <td>Pressure Ratio</td>
              <td>35.5</td>
              <td><span className="status-dot"></span> Normal</td>
            </tr>
          </tbody>
        </table>
      </div>
      <div className="card">
        <h3>Controls</h3>
        <button className="btn btn-primary" onClick={() => setEngineRPM(prev => Math.min(prev + 100, 12000))}>Zoom In</button>
        <button className="btn btn-primary" onClick={() => setEngineRPM(prev => Math.max(prev - 100, 1000))}>Zoom Out</button>
        <button className="btn btn-secondary" onClick={() => setEngineSection(prev => prev === "full" ? "section" : "full")}>Toggle Section View</button>
        <button className="btn btn-danger" onClick={() => setEngineSection("exploded")}>Exploded View</button>
      </div>
      <canvas id="engine-canvas" className="canvas-gl" />
    </section>
  )
function AircraftScreen({ setScreen }) {
  return (
    <section className="screen aircraft">
      <h2>3D Aircraft Model</h2>
      <div className="card">
        <h3>Aircraft Selection</h3>
        <button className="btn btn-primary">Select Boeing 777</button>
        <button className="btn-primary">Select Airbus A320</button>
        <button className="btn-secondary">Select Fighter Jet</button>
      </div>
      <canvas className="canvas-gl" />
    </section>
  )
}
function AnalysisScreen() {
  return (
    <section className="screen analysis">
      <h2>Performance Analysis</h2>
      <div className="tab-btns">
        <button className="tab-btn active">Flight Data</button>
        <button className="tab-btn">System Health</button>
        <button className="tab-btn">Fuel Efficiency</button>
      </div>
      <div className="table">
        <thead>
          <tr>
            <th>Metric</th>
            <th>Value</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>Total Flight Time</td>
            <td>12,450 hrs</td>
            <td><span className="status-dot"></span> Optimal</td>
          </tr>
          <tr>
            <td>Maintenance Interval</td>
            <td>5,000 hrs</td>
            <td><span className="status-dot"></span> On Schedule</td>
          </tr>
        </tbody>
      </div>
    </section>
  )
}
function DrawingsScreen() {
  return (
    <section className="screen drawings">
      <h2>Technical Drawings</h2>
      <div className="tab-btns">
        <button className="tab-btn active">2D Drawings</button>
        <button className="tab-btn">3D Models</button>
        <button className="tab-btn">PDF Export</button>
      </div>
      <p>Drawing files and models will be displayed here.</p>
    </section>
  )
}

export default App
